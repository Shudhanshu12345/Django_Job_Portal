from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import JobProfile
from .serializers import JobSerializer
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.models import User
from .serializers import LoginSerializer
from django.http import JsonResponse
from .models import JobTitle
from .models import JobCategory
from .models import JobType



class RegisterAPIView(APIView):
    def post(self, request):
        serializer = JobSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': "Register Successful"}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginApiView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            password = serializer.validated_data['password']
            try:
                user = JobProfile.objects.get(email=email)
            except JobProfile.DoesNotExist:
                return Response({'error': 'Invalid email or password'}, status=status.HTTP_401_UNAUTHORIZED)
            if password == user.password:
                refresh = RefreshToken.for_user(user)
                return Response({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'message': 'Login Successful'
                }, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Invalid email or password'}, status=status.HTTP_401_UNAUTHORIZED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


def get_all_job_titles(request):
    title = list(JobTitle.objects.all().values('id', 'role'))
    return JsonResponse(title, safe=False)


def get_all_job_category(request):
    category = list(JobCategory.objects.all().values('id', 'category'))
    return JsonResponse(category, safe=False)


def get_all_job_type(request):
    type = list(JobType.objects.all().values('id', 'type'))
    return JsonResponse(type, safe=False)
