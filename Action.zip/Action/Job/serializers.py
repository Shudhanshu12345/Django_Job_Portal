from rest_framework import serializers
from .models import JobProfile


class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobProfile
        fields = '__all__'

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Name is required.")
        return value

    def validate_email(self, value):
        if not value.strip():
            raise serializers.ValidationError("Email is required.")
        return value

    def validate_password(self, value):
        if not value.strip():
            raise serializers.ValidationError("Password is required.")
        return value

    def validate_number(self, value):
        if not value.strip():
            raise serializers.ValidationError("Phone number is required.")
        return value

    def validate_age(self, value):
        if value is None:
            raise serializers.ValidationError("Age is required.")
        return value


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)
