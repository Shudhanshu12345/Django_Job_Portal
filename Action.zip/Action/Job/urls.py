from django.urls import path
from .views import RegisterAPIView, LoginApiView, get_all_job_titles, get_all_job_category, get_all_job_type

urlpatterns = [
    path('register/', RegisterAPIView.as_view(), name='register'),
    path('login/', LoginApiView.as_view(), name='login'),
    path('title/', get_all_job_titles),
    path('category/', get_all_job_category),
    path('type/', get_all_job_type),
]
