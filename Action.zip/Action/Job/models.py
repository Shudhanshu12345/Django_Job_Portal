from django.db import models



class JobProfile(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    number = models.CharField(max_length=15)
    age = models.IntegerField()

    def __str__(self):
        return self.email


class JobType(models.Model):
    type = models.CharField(max_length=100)

    def __str__(self):
        return self.type


class JobCategory(models.Model):
    category = models.CharField(max_length=100)

    def __str__(self):
        return self.category


class JobTitle(models.Model):
    role = models.CharField(max_length=100)

    def __str__(self):
        return self.role


class JobCreate(models.Model):
    name = models.CharField(max_length=200)
    job_description = models.TextField()

    job_type = models.ForeignKey(
        'JobType', on_delete=models.SET_NULL, null=True)
    job_category = models.ForeignKey(
        'JobCategory', on_delete=models.SET_NULL, null=True)
    job_role = models.ForeignKey(
        'JobTitle', on_delete=models.SET_NULL, null=True)
    work_mode = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    address = models.TextField()

    qualification = models.CharField(max_length=100)
    experience = models.CharField(max_length=100)
    skills = models.TextField()

    salary = models.CharField(max_length=100)
    benefits = models.TextField()
    vacancies = models.IntegerField()

    company_name = models.CharField(max_length=150)
    company_email = models.CharField(max_length=150)
    company_logo = models.ImageField(
        upload_to='company_logos/', blank=True, null=True)

    job_shift = models.CharField(max_length=50)
    language_speak = models.CharField(max_length=100)
    apply_this = models.CharField(max_length=150)

    def __str__(self):
        return self.name


# Create your models here.
